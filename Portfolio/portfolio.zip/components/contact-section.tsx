import { Mail, Calendar, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ContactSection() {
  return (
    <section id="contact" className="pb-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mx-auto max-w-3xl rounded-[2rem] border border-border bg-card p-8 text-center shadow-xl shadow-primary/5 sm:p-14">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">
            Get in touch
          </span>
          <h2 className="mt-3 text-balance font-heading text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl">
            Ready to plan your next step?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Whether you&apos;re a student or a parent, I&apos;m happy to talk
            through your options. Reach out and I&apos;ll get back to you to
            arrange a consultation.
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button
              size="lg"
              nativeButton={false}
              className="rounded-full px-7 text-base"
              render={<a href="mailto:sarah.whitfield@britacademylondon.ac.uk" />}
            >
              <Mail className="size-4" />
              Email me
            </Button>
            <Button
              size="lg"
              variant="outline"
              nativeButton={false}
              className="rounded-full border-border bg-transparent px-7 text-base"
              render={<a href="mailto:sarah.whitfield@britacademylondon.ac.uk" />}
            >
              <Calendar className="size-4" />
              Book a consultation
            </Button>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              Brit Academy London
            </span>
            <a
              href="#top"
              className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground"
            >
              LinkedIn <ArrowRight className="size-3.5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
