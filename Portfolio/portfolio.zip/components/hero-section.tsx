import Image from "next/image"
import { ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="mx-auto max-w-6xl px-4 pb-16 pt-16 sm:px-6 sm:pt-24">
        <div className="flex flex-col items-center text-center">
          <span className="mb-6 inline-flex items-center gap-2 rounded-full bg-secondary px-4 py-1.5 text-sm font-medium text-secondary-foreground">
            <Sparkles className="size-4" />
            Academic Coordinator · Brit Academy London
          </span>

          <h1 className="max-w-4xl text-balance font-heading text-5xl font-bold leading-[1.05] tracking-tight text-foreground sm:text-6xl md:text-7xl">
            Guiding students toward their{" "}
            <span className="text-primary">academic future</span>.
          </h1>

          <p className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">
            {
              "Hi, I'm Sarah Whitfield. As an Academic Coordinator at Brit Academy London, I help students plan their studies, choose the right pathways, and apply to university with clarity and confidence."
            }
          </p>

          <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row">
            <Button
              size="lg"
              nativeButton={false}
              className="rounded-full px-7 text-base"
              render={<a href="#contact" />}
            >
              Book a consultation
              <ArrowRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              nativeButton={false}
              className="rounded-full border-border bg-transparent px-7 text-base"
              render={<a href="#services" />}
            >
              How I can help
            </Button>
          </div>
        </div>

        {/* Hero visual */}
        <div className="relative mx-auto mt-16 max-w-3xl">
          <div className="blob-1 absolute -left-10 -top-10 -z-10 size-72 bg-primary/15 blur-2xl" />
          <div className="blob-2 absolute -bottom-10 -right-10 -z-10 size-72 bg-primary/10 blur-2xl" />

          <div className="grid items-center gap-6 rounded-3xl border border-border bg-card p-6 shadow-xl shadow-primary/5 sm:grid-cols-[1fr_1.2fr] sm:p-8">
            <div className="relative mx-auto aspect-[4/5] w-full max-w-[260px] overflow-hidden rounded-2xl">
              <Image
                src="/maya-portrait.png"
                alt="Portrait of Sarah Whitfield, Academic Coordinator at Brit Academy London"
                fill
                priority
                className="object-cover"
                sizes="260px"
              />
            </div>
            <div className="grid gap-4">
              {[
                { stat: "12+ yrs", label: "Supporting students across UK education" },
                { stat: "1,500+", label: "Students guided through their studies" },
                { stat: "95%", label: "Of applicants placed at a top-choice course" },
              ].map((item) => (
                <div
                  key={item.stat}
                  className="rounded-2xl bg-secondary/60 p-4"
                >
                  <p className="font-heading text-2xl font-bold text-primary">
                    {item.stat}
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {item.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
