const brands = [
  "UCL",
  "King's College",
  "Manchester",
  "Edinburgh",
  "Warwick",
  "Bristol",
]

export function BrandStrip() {
  return (
    <section className="border-y border-border bg-muted/40 py-10">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <p className="text-center text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Students placed at leading UK universities
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
          {brands.map((brand) => (
            <span
              key={brand}
              className="font-heading text-xl font-semibold text-foreground/40 transition-colors hover:text-foreground/70"
            >
              {brand}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
