import { Check } from "lucide-react"

const highlights = [
  "Academic Coordinator at Brit Academy London",
  "One-to-one counselling on course choice and academic pathways",
  "UCAS and university application guidance, including personal statements",
  "Pastoral support to keep students motivated and on track",
]

export function AboutSection() {
  return (
    <section id="about" className="py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">
              About me
            </span>
            <h2 className="mt-3 text-balance font-heading text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl">
              Every student deserves a clear path forward.
            </h2>
            <div className="mt-6 space-y-4 text-lg leading-relaxed text-muted-foreground">
              <p>
                {
                  "I've spent over a decade in education, helping young people navigate the choices that shape their future. At Brit Academy London, I coordinate academic programmes and work closely with students at every step of their journey."
                }
              </p>
              <p>
                {
                  "Beyond timetables and coursework, I counsel students on their academic careers — from picking the right subjects to applying for university. My goal is simple: help each student make confident, informed decisions about what comes next."
                }
              </p>
            </div>

            <ul className="mt-8 grid gap-3">
              {highlights.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Check className="size-4" />
                  </span>
                  <span className="leading-relaxed text-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="relative">
            <div className="blob-2 absolute -right-6 -top-8 -z-10 size-64 bg-primary/10 blur-2xl" />
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-3xl bg-primary p-6 text-primary-foreground">
                <p className="font-heading text-4xl font-bold">1,500+</p>
                <p className="mt-2 text-sm leading-relaxed text-primary-foreground/80">
                  Students supported through their studies
                </p>
              </div>
              <div className="mt-8 rounded-3xl bg-secondary p-6">
                <p className="font-heading text-4xl font-bold text-foreground">
                  95%
                </p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Placed on a top-choice university course
                </p>
              </div>
              <div className="rounded-3xl border border-border bg-card p-6">
                <p className="font-heading text-4xl font-bold text-foreground">
                  12+
                </p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Years working in UK education
                </p>
              </div>
              <div className="mt-8 rounded-3xl bg-accent p-6">
                <p className="font-heading text-4xl font-bold text-accent-foreground">
                  1:1
                </p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Personal guidance for every student
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
